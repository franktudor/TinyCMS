// JavaScript Document
$(document).ready(function() {
	//$('#pageHeader').corner("top 10px");
 });

$(document).ready(function(){ $('#blogg').jshowoff({ 
					links: false,
					controls: false,
					effect: 'fade',
					cssClass: 'blogg',
					hoverPause: false,
					speed:9999 
				}); });






