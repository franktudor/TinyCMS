JavaLoader v1.0
Author: Mark Mandel
Date: 10 September 2010

Documentation can now be found at:
http://www.compoundtheory.com/javaloader/docs/